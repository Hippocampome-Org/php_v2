sim.setSpikeMonitor(CA1_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Cajal_Retzius, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Radiatum_Giant, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Axo_Axonic, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Horizontal_Axo_Axonic, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Back_Projection, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Basket, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Horizontal_Basket, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Basket_CCK, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Bistratified, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Interneuron_Specific_LMO_O, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Interneuron_Specific_LM_R, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Interneuron_Specific_LMR_R, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Interneuron_Specific_O_R, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Interneuron_Specific_O_Targeting_QuadD, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Interneuron_Specific_R_O, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Interneuron_Specific_RO_O, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Ivy, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_LMR, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_LMR_Projecting, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Neurogliaform, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Neurogliaform_Projecting, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_O_LM, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Recurrent_O_LM, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_O_LMR, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Oriens_Alveus, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Oriens_Bistratified, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Oriens_Bistratified_Projecting, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_OR_LM, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Perforant_Path_Associated, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Perforant_Path_Associated_QuadD, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Quadrilaminar, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Radiatum, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_R_Receiving_Apical_Targeting, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Schaffer_Collateral_Associated, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Schaffer_Collateral_Receiving_R_Targeting, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_SO_SO, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Hippocampo_Subicular_Projecting_ENK, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Trilaminar, "DEFAULT");
                             
sim.setSpikeMonitor(CA1_Radial_Trilaminar, "DEFAULT");
                             
