sim.setSpikeMonitor(SUB_EC_Projecting_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(SUB_CA1_Projecting_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(SUB_Axo_Axonic, "DEFAULT");
                             
