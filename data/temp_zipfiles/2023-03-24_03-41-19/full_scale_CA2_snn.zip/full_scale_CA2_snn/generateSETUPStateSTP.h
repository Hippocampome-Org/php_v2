sim.setSpikeMonitor(CA2_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(CA2_Basket, "DEFAULT");
                             
sim.setSpikeMonitor(CA2_Wide_Arbor_Basket, "DEFAULT");
                             
sim.setSpikeMonitor(CA2_Bistratified, "DEFAULT");
                             
sim.setSpikeMonitor(CA2_SP_SR, "DEFAULT");
                             
