sim.setSpikeMonitor(CA3_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(CA3c_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Giant, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Granule, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Axo_Axonic, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Horizontal_Axo_Axonic, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Basket, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Basket_CCK, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Bistratified, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Interneuron_Specific_Oriens, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Interneuron_Specific_Quad, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Ivy, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_LMR_Targeting, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Lucidum_LAX, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Lucidum_ORAX, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Lucidum_Radiatum, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Spiny_Lucidum, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Mossy_Fiber_Associated, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Mossy_Fiber_Associated_ORDEN, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_O_LM, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_QuadD_LM, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Radiatum, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_R_LM, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_SO_SO, "DEFAULT");
                             
sim.setSpikeMonitor(CA3_Trilaminar, "DEFAULT");
                             
